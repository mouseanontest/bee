# Bee of All Trades
Bee of all trades is a game for 2 players. We have to create as many minigames as possible and whoever wins the most wins the game.
# Why
idk
# How
Phaser
# What
am I doing
